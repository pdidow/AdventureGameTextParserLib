﻿using System;
using System.Collections.Generic;
using System.Text;

namespace AdventureGameTextParserLib
{
    public class TextParser
    {
        private readonly List<string> _verbs;
        private readonly List<string> _nouns;
        private readonly List<string> _articles;
        private readonly List<string> _prepositions;
        private StringBuilder stringBuilder = new StringBuilder();
        public TextParser()
        {
            // Initialize the lists of verbs, nouns, articles, and prepositions
            _verbs = new List<string>
            {
                "go", "move", "walk", "run", "travel",
                "pick up", "grab", "take", "obtain",
                "drop", "put down",
                "examine", "inspect", "look at",
                "use", "activate", "employ",
                "help", "hint", "clue",
                "save", "load", "restore"
            };

            _nouns = new List<string>
            {
                "room", "door", "key", "treasure", "monster"
            };

            _articles = new List<string>
            {
                "a", "an", "the"
            };

            _prepositions = new List<string>
            {
                "and", "but", "or", "for", "nor", "yet", "so"
            };
        }
        public StringBuilder ParseText(string text)
        {
            // Split the text into words
            string[] words = text.Split(' ');

            // Iterate through the words and try to recognize them
            foreach (string word in words)
            {
                if (_verbs.Contains(word))
                {
                    // The word is a verb, handle it
                    HandleVerb(word);
                }
                else if (_nouns.Contains(word))
                {
                    // The word is a noun, handle it
                    HandleNoun(word);
                }
                else if (_articles.Contains(word))
                {
                    // The word is an article, handle it
                    HandleArticle(word);
                }
                else if (_prepositions.Contains(word))
                {
                    // The word is a preposition, handle it
                    HandlePreposition(word);
                }
                else
                {
                    // The word is not recognized
                    Console.WriteLine("I'm sorry, I don't understand the word '{0}'.", word);
                }
            }
            stringBuilder.AppendLine("Verbs: " + string.Join(", ",_verbs));

            //Console.WriteLine("Nouns: " + string.Join(", ", nounList));
            stringBuilder.AppendLine("Nouns: " + string.Join(", ", _nouns));
            //Console.WriteLine("Prepositions: " + string.Join(", ", prepositionList));
            stringBuilder.AppendLine("Prepositions: " + string.Join(", ", _prepositions));
            //Console.WriteLine("Preposition Objects: " + string.Join(", ", prepositionObjectList));
            stringBuilder.AppendLine("Articles:" + string.Join(", ", _articles));
            return stringBuilder;
        }
        private void HandleVerb(string verb)
        {
            // Determine what action to take based on the verb
            switch (verb)
            {
                case "go":
                case "move":
                case "walk":
                case "run":
                case "travel":
                    // Handle movement commands
                    Console.WriteLine("Moving player character...");
                    break;
                case "pick up":
                case "grab":
                case "take":
                case "obtain":
                    // Handle item pickup commands
                    Console.WriteLine("Picking up item...");
                    break;
                case "drop":
                case "put down":
                    // Handle item drop commands
                    Console.WriteLine("Dropping item...");
                    break;
                case "examine":
                case "inspect":
                case "look at":
                    // Handle examination commands
                    Console.WriteLine("Examining item...");
                    break;
                case "use":
                case "activate":
                case "employ":
                    // Handle use commands
                    Console.WriteLine("Using item...");
                    break;
                case "help":
                case "hint":
                case "clue":
                    // Handle help commands
                    Console.WriteLine("Displaying help message...");
                    break;
                case "save":
                    // Handle save commands
                    Console.WriteLine("Saving game...");
                    break;
                case "load":
                    // Handle load commands
                    Console.WriteLine("Loading game...");
                    break;
                case "restore":
                    // Handle restore commands
                    Console.WriteLine("Restoring game...");
                    break;
            }
        }
        private void HandleNoun(string noun)
        {
            // Determine what action to take based on the noun
            switch (noun)
            {
                case "room":
                    // Handle room noun
                    break;
                case "door":
                    // Handle door noun
                    break;
                case "key":
                    // Handle key noun
                    break;
                case "treasure":
                    // Handle treasure noun
                    break;
                case "monster":
                    // Handle monster noun
                    break;
            }
        }
        private void HandleArticle(string article)
        {
            // Determine what action to take based on the article
            switch (article)
            {
                case "a":
                    // Handle "a" article
                    break;
                case "an":
                    // Handle "an" article
                    break;
                case "the":
                    // Handle "the" article
                    break;
            }
        }
        private void HandlePreposition(string preposition)
        {
            // Determine what action to take based on the preposition
            switch (preposition)
            {
                case "and":
                    // Handle "and" preposition
                    break;
                case "but":
                    // Handle "but" preposition
                    break;
                case "or":
                    // Handle "or" preposition
                    break;
                case "for":
                    // Handle "for" preposition
                    break;
                case "nor":
                    // Handle "nor" preposition
                    break;
                case "yet":
                    // Handle "yet" preposition
                    break;
                case "so":
                    // Handle "so" preposition
                    break;
            }
        }

    }
}
